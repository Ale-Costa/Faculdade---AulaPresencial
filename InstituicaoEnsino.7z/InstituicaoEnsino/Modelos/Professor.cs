﻿namespace Modelos
{
    public class Professor
    {


        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }


        public int Matricula { get; set; }

    }
}
    

