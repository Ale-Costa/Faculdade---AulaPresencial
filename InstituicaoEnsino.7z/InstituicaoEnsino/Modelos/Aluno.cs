﻿namespace Modelos
{
    public class Aluno
    {
        private string nome;

        public string Nome 
        {
            get { return nome; }
            set { nome = value; }
        }


        public int Matricula { get; set; }
    }
}
