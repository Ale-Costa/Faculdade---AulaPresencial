﻿namespace Modelos
{
   public class Disciplina
    {

        private string nome;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }


        public int Id { get; set; }


    }
}
